# KAster CTI 운영 배포 절차

작성일: 2026-04-16

## 운영 환경 정보

| 항목 | 값 |
|------|----|
| 원격 서버 | `blueadm@49.247.46.86` |
| 원격 경로 | `/home/blueadm/kaster_cti` |
| 배포 방식 | Docker Compose dev (`bind mount + hot reload`) |
| 기본 배포 도구 | [`scripts/deploy-dev.sh`](/D:/Work/AI_Projects/KAster_CTI/scripts/deploy-dev.sh) |

## 일상 코드 배포

가장 자주 쓰는 배포 경로다.

1. 로컬 변경사항 커밋
```bash
git commit -m "feat: ..."
```

2. 변경 파일만 원격 전송
```bash
./scripts/deploy-dev.sh sync
```

메모:
- `rsync` 기반 전송이라 보통 1초 내외로 끝난다.
- 서버 `start:dev` watch가 자동 재컴파일하므로 일반적으로 별도 restart가 필요 없다.
- `web/admin`도 Vite HMR로 즉시 반영된다.

## 최초 설치 / 서버 재구축

원격 경로에 소스를 동기화하고 Compose를 다시 올린다.

```bash
./scripts/deploy-dev.sh up
```

메모:
- 최초 `node_modules` 설치가 포함된다.
- `prisma db push`, seed, watch 기동까지 포함되어 있어 3~5분 정도 걸릴 수 있다.

## Prisma 스키마 변경 배포

Prisma 스키마가 바뀐 경우는 아래 순서를 따른다.

1. 파일 동기화
```bash
./scripts/deploy-dev.sh sync
```

2. 원격 `server` 컨테이너에서 스키마 반영
```bash
ssh blueadm@49.247.46.86 "
  cd /home/blueadm/kaster_cti && \
  docker exec kaster-server sh -c 'npx prisma db push --skip-generate'
"
```

3. 필요 시 `server` 컨테이너 재시작
```bash
./scripts/deploy-dev.sh restart server
```

메모:
- watch가 정상적으로 살아 있으면 재시작은 생략 가능하다.
- 현재 운영 절차는 `migrate deploy`가 아니라 `db push` 기준이다.

## 컨테이너 제어

전체 재시작:
```bash
./scripts/deploy-dev.sh restart
```

서버만 재시작:
```bash
./scripts/deploy-dev.sh restart server
```

전체 종료:
```bash
./scripts/deploy-dev.sh down
```

메모:
- `down`은 데이터를 유지하는 종료 절차다.

## 로그 확인

서버 로그:
```bash
./scripts/deploy-dev.sh logs
```

관리자 앱 로그:
```bash
./scripts/deploy-dev.sh logs admin
```

상담원 앱 로그:
```bash
./scripts/deploy-dev.sh logs web
```

## 서비스 접속 URL

| 서비스 | URL |
|--------|-----|
| NestJS API | [http://49.247.46.86:3000/api/v1](http://49.247.46.86:3000/api/v1) |
| Swagger | [http://49.247.46.86:3000/docs](http://49.247.46.86:3000/docs) |

## 운영 배포 체크리스트

- 코드 변경 후 `./scripts/deploy-dev.sh sync` 수행
- Prisma 변경이 있으면 원격 `db push --skip-generate` 수행
- 필요 시 `./scripts/deploy-dev.sh restart server`
- `./scripts/deploy-dev.sh logs`로 에러 여부 확인
- API/Swagger 접속 확인
- 기능 변경이 크면 관리자/상담원 주요 화면에서 수동 스모크 테스트 수행

## 주의사항

- 현재 운영 배포는 개발형 Compose(`bind mount + hot reload`) 기반이다.
- 운영서버 파일과 컨테이너 상태가 실시간으로 연결되므로, `sync` 직후 로그를 꼭 확인해야 한다.
- Asterisk/Prisma 관련 변경은 일반 프론트 수정과 달리 원격 후속 명령이 필요할 수 있다.
